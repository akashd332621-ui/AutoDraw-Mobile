# Build the AutoDraw APK using only your phone

This project is Android app source code. The workflow in `.github/workflows/build-apk.yml` builds an installable debug APK online, so you do not need a PC to compile it.

1. Sign in to GitHub in your phone browser and create a new repository. If prompted, make it private.
2. Upload the contents of this ZIP to the repository, keeping the folders and files in their original locations. The `.github/workflows/build-apk.yml` file must be included.
3. If GitHub does not start the build automatically, open the repository's **Actions** tab, choose **Build AutoDraw APK**, tap **Run workflow**, and confirm.
4. Wait for the run to finish successfully. Open that run, scroll to **Artifacts**, and download **AutoDraw-debug-apk**.
5. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow your browser or file manager to install unknown apps; only continue because you built this APK from your own project.
6. Open AutoDraw. To replay strokes in another app, Android requires you to explicitly enable its AutoDraw Accessibility Service in Settings. Review the permissions and use it only in apps where automated touch input is allowed.

If the build fails, open the failed Actions run and share the error log so the project can be corrected.
